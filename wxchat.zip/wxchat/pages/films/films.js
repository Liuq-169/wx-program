// pages/films/films.js
var QQMapWX = require('../../utils/wx-jssdk.min.js')
var { globalData } = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bannerObj: {
      "status": 0,
      "data": [{
        "bannerId": 247,
        "actionType": 2,
        "actionData": "{\"url\":\"https://m.maizuo.com/mz-act/brand/groupon/sUnSV582yL?partnerId=mz\u0026co=mzmovie\"}",
        "imgUrl": "https://static.maizuo.com/v5/upload/c59274dc30989e9a374adc64ff567da4.jpg",
        "masterTitle": "",
        "slaveTitle": "",
        "displayOrder": 0,
        "bindBusinessId": "",
        "cityIds": "310100",
        "name": "上海万达邀您特惠观影",
        "displayTimes": 0,
        "slaveImgUrl": "",
        "startTime": "1571932800",
        "endTime": "1581091199",
        "businessId": ""
      },
      {
        "bannerId": 326,
        "actionType": 22,
        "actionData": "{\"businessId\":\"4917\"}",
        "imgUrl": "https://static.maizuo.com/v5/upload/b27e2f1ca2c7e6c2748f78131855bfc5.jpg",
        "masterTitle": "",
        "slaveTitle": "",
        "displayOrder": 0,
        "bindBusinessId": "",
        "cityIds": "0",
        "name": "天气之子",
        "displayTimes": 0,
        "slaveImgUrl": "",
        "startTime": "1572537600",
        "endTime": "1573228799",
        "businessId": ""
      },
      {
        "bannerId": 327,
        "actionType": 22,
        "actionData": "{\"businessId\":\"4918\"}",
        "imgUrl": "https://static.maizuo.com/v5/upload/b93301a27c59f90ecd860f6501900d15.jpg",
        "masterTitle": "",
        "slaveTitle": "",
        "displayOrder": 0,
        "bindBusinessId": "",
        "cityIds": "0",
        "name": "终结者：黑暗命运",
        "displayTimes": 0,
        "slaveImgUrl": "",
        "startTime": "1572537600",
        "endTime": "1573228799",
        "businessId": ""
      }
      ],
    },
    city: '',
    filmParams: {
      cityId: "",
      pageNum: 1,
      pageSize: 10,
      type: 1 //1：正在 2：即将
    },
    filmList:[],
    onReachBottom_num : 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //页面加载的时候获取地理信息

    let qqmapsdk = new QQMapWX({
      key: '62HBZ-E7ZCJ-UVCFJ-KL7BI-GWFE5-4XBUF'
    })

    if (!this.data.city) {
      var that = this
      wx.getLocation({ //获取用户地理位置信息
        success(res) { //成功的回调
          //拿到了经纬度 通过腾讯的api 去反查位置信息
          qqmapsdk.reverseGeocoder({
            location: {
              latitude: res.latitude,
              longitude: res.longitude
            },
            success({ result }) {
              let city = result.ad_info.city
              let cityId = result.ad_info.city_code
              console.log(result)
              that.setData({
                city: city
              })
              that.data.filmParams.cityId = cityId
            }
          })
          //当cityId拿到后，在执行获取基本数据的函数
          that.getFlimList(that.data.filmParams)
        },
        fail() {
          that.data.filmParams.cityId = "510100" //失败后的默认id
          //当cityId拿到后，在执行获取基本数据的函数
          that.getFlimList(that.data.filmParams)
        }
      })
    }

    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.data.filmParams.pageNum = 1
    this.getFlimList(this.data.filmParams)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    //下拉加载更多，改变完pageNum
    this.data.filmParams.pageNum += 1
    this.getFlimList(this.data.filmParams,true)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  handleOpenLocation() {
    wx.openLocation({
      latitude: 30.537,
      longitude: 104.055,
      name: '向前',
      address: "地址详情"
    })
  },

  handleChoiceLocation() {
    wx.chooseLocation({
      success: function (res) {
        console.log("选择地理位置以打开")
      },
    })
  },

  handleNavChang(event) {
    this.setData({
      'filmParams.type': event.target.dataset.type
    },()=>{
      this.getFlimList(this.data.filmParams)
    })
  },


  getFlimList(filmParams,more = false){
    //往后台发送请求，渲染基本页面数据
    wx.request({
      url: globalData.url + '/api/filmlist',
      data: filmParams,
      success:(res)=> {
        if(more){
          this.setData({
            filmList: [...this.data.filmList,...res.data.data.films]
          })
        }else{
          this.setData({
            filmList: res.data.data.films
          })
        }
        
      }
    })
  }
})