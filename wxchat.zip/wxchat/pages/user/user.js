// pages/user/user.js

var app = getApp()//拿到app.js中的全局数据
Page({

  /**
   * 页面的初始数据
   */
  data: { //和vue 的数据一个意思
    title:{
      name:'bobo', 
    },
    count: 1 ,
    _id:'cd001'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // console.log(app.globalData)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      var pages = getCurrentPages() //获取当前页面的实例
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
      console.log("我到底了！")
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  handelCount(event){
    if(event.target.dataset.type == "add"){
      this.setData({
        count: this.data.count + 1
      })
    }else{
      this.setData({
        count: this.data.count - 1
      })
    }
    console.log(event)
  },
  handleGoindex(){
    //query跳转 //并传递_id
    wx.navigateTo({
      url: '/pages/index/index?_id='+this.data._id,
      success(){
        console.log("跳转成功")
      }
    })
  },
  handleGofilms(){
    wx.switchTab({
      url: '/pages/films/films',
      success(){
        console.log("跳转成功")
      }
    })
  },
  handleCount({ detail }) { //Count组件事件处理
    console.log(detail)
    this.setData({
      count: detail
    })
  },
})