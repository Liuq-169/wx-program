// assets/components/filmitem/filmitem.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    film:Object,
  },

  /**
   * 组件的初始数据
   */
  data: {
  },

  /**
   * 组件的方法列表
   */
  methods: {
    
    // getTime(inputTime){
    //     var date = new Date(inputTime);
    //     var y = date.getFullYear();
    //     var m = date.getMonth() + 1;
    //     m = m < 10 ? ('0' + m) : m;
    //     var d = date.getDate();
    //     d = d < 10 ? ('0' + d) : d;
    //     var h = date.getHours();
    //     h = h < 10 ? ('0' + h) : h;
    //     var minute = date.getMinutes();
    //     var second = date.getSeconds();
    //     minute = minute < 10 ? ('0' + minute) : minute;
    //     second = second < 10 ? ('0' + second) : second;
    //     return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
    // }
  }
})
