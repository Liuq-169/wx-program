// assets/components/counter/counter.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    count:{
      type:[String,Number],
      default:0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  behaviors:[],//相当于vue中的 mixins 、可在组件的内部实现调用

  /**
   * 组件的方法列表
   */
  methods: {
    handleCount(event){  
      if(event.target.dataset.type == "add"){
        if (this.properties.count<10){
          this.triggerEvent("handlecount", this.properties.count + 1)
        }
      }else{
        if (this.properties.count>0){
          this.triggerEvent("handlecount", this.properties.count - 1)
        }
      }
    }
  },
  // 生命周期

  pageLifetimes:{//组件所在页面发生的改变的时候执行的钩子函数

  },

  lifetimes:{//存放组件自己内部的生命周期钩子函数
    ready(){
      console.log('ready生命周期钩子函数执行')
    }
  }
})
